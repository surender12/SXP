//
//  SXCMeetVC.h
//  SXC
//
//  Created by Ketan on 09/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RESideMenu.h"
#import <MessageUI/MessageUI.h>

@interface SXCMeetVC : UIViewController<MFMailComposeViewControllerDelegate>
- (IBAction)btnPressed_LetMeKnow:(id)sender;

@end
