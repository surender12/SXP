//
//  SXCFilterTblVW.m
//  SXC
//
//  Created by Ketan on 16/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCFilterTblVW.h"

@implementation SXCFilterTblVW
@synthesize blockFilter;

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void)callSetup{
    arrList = [[NSMutableArray alloc]initWithObjects:@"What I think of me",@"What others say of me",@"Individuals rating",@"Alesia",@"Morgan",@"Ramn", nil];
    
    [tbl_Filter reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return arrList.count;    //count number of row from counting array hear cataGorry is An Array
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"filterCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SXCFilterCell" owner:self options:nil];
        cell = (UITableViewCell *)[nib objectAtIndex:0];
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
//                                       reuseIdentifier:MyIdentifier];
        
        
        UIView *bgColorView = [[UIView alloc] init];
        bgColorView.backgroundColor = [UIColor colorWithRed:79.0f/255.0f green:193.0f/255.0f blue:100.0f/255.0f alpha:1.0f];
        [cell setSelectedBackgroundView:bgColorView];

    }
   
    UIButton * imgVwPic = (UIButton*)[cell viewWithTag:1001];
    UILabel * lblTitle = (UILabel*)[cell viewWithTag:1002];
    if (imgVwPic) {
        if (indexPath.row == 0 || indexPath.row == 1 || indexPath.row == 2) {
            [imgVwPic setImage:[UIImage imageNamed:@"filterTick"] forState:UIControlStateNormal];
        }else
            [imgVwPic setImage:[UIImage imageNamed:@"avatar.png"] forState:UIControlStateNormal];
    }
    if (lblTitle) {
        lblTitle.text = arrList[indexPath.row];
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    NSMutableDictionary * dict = [[NSMutableDictionary alloc]init];
    [dict setValue:arrList[indexPath.row] forKey:@"title"];
    self.blockFilter(dict);
    [self removeFromSuperview];
}

- (IBAction)btnPressed_Close:(id)sender {
    
    [self removeFromSuperview];
}
@end
