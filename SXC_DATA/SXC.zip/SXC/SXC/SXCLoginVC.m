//
//  SXCLoginVC.m
//  SXC
//
//  Created by Ketan on 17/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCLoginVC.h"
#import "SXCRootMenuVC.h"

@interface SXCLoginVC ()

@end

@implementation SXCLoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (IS_IPHONE_4) {
        imgVwBackground.image = [UIImage imageNamed:@"backgroundImg4"];
    }else
        imgVwBackground.image = [UIImage imageNamed:@"backgroundImg"];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBarHidden = YES;
}


-(void)callSignInAPI{
    [ApplicationDelegate loadingShow];
//      http://www.trigmasolutions.com/SexSkill/api/LoginCheck
    
//      Keys: EmailId,Password,DeviceToken,DeviceType
    
    NSMutableDictionary * dictData = [[NSMutableDictionary alloc]init];
    
    [dictData setValue:txtFld_username.text forKey:@"EmailId"];
    [dictData setValue:@"iphone" forKey:@"DeviceType"];
    [dictData setValue:@"rew67erw66erw7t6ert7" forKey:@"DeviceToken"];
    [dictData setValue:txtFld_password.text forKey:@"Password"];
    
    [[SXCUtility singleton] getDataForUrl:LoginAPI parameters:dictData success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [ApplicationDelegate loadingDismiss];
        NSLog(@"responseObject---%@",responseObject);
        
        if (responseObject && [responseObject valueForKey:@"Status"] && [[responseObject valueForKey:@"Status"] boolValue] == YES) {
        
            NSMutableDictionary *dictData = [[NSMutableDictionary alloc]init];
            if ([responseObject valueForKey:@"EmailId"] && [responseObject valueForKey:@"UserID"]) {
                [dictData setValue:[responseObject valueForKey:@"EmailId"] forKey:@"email"];
                [dictData setValue:[responseObject valueForKey:@"UserID"] forKey:@"userid"];
                
                [UserDefaults setObject:dictData forKey:@"userData"];
                [UserDefaults synchronize];
            }
        
        SXCRootMenuVC * objPre = VCWithIdentifier(@"SXCRootMenuVC");
        [self.navigationController pushViewController:objPre animated:YES];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [ApplicationDelegate loadingDismiss];
        
    }];
    
    
}

-(void)callRegisterAPI : (NSDictionary *)fbData{
    [ApplicationDelegate loadingShow];
    //        Usertype --->"Facebook","Email","UnVerified"
    //        Keys:Username,Email,PhoneNumber,DeviceType,DeviceToken,Usertype,password(This key will be used for Email,Facebook)
    
    NSMutableDictionary * dictData = [[NSMutableDictionary alloc]init];
    
        [dictData setValue:[fbData valueForKey:@"name"] forKey:@"Username"];
        if ([fbData valueForKey:@"email"]) {
            [dictData setValue:[fbData valueForKey:@"email"] forKey:@"Email"];
        }
        [dictData setValue:@"" forKey:@"PhoneNumber"];
        [dictData setValue:@"" forKey:@"password"];
  
    [dictData setValue:@"iphone" forKey:@"DeviceType"];
    [dictData setValue:@"rew67erw66erw7t6ert7" forKey:@"DeviceToken"];
    [dictData setValue:@"Facebook" forKey:@"Usertype"];
    
    
    [[SXCUtility singleton] getDataForUrl:RegistrationLink parameters:dictData success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"responseObject---%@",responseObject);
        
        [ApplicationDelegate loadingDismiss];
        if (responseObject && [responseObject valueForKey:@"status"] && [[responseObject valueForKey:@"status"] boolValue] == YES) {
            
            NSMutableDictionary *dictData = [[NSMutableDictionary alloc]init];
            if ([responseObject valueForKey:@"Email"] && [responseObject valueForKey:@"UserId"]) {
                [dictData setValue:[responseObject valueForKey:@"Email"] forKey:@"email"];
                [dictData setValue:[responseObject valueForKey:@"UserId"] forKey:@"userid"];
                
                [UserDefaults setObject:dictData forKey:@"userData"];
                [UserDefaults synchronize];
            }
            
            SXCRootMenuVC * objPre = VCWithIdentifier(@"SXCRootMenuVC");
            [self.navigationController pushViewController:objPre animated:YES];
        }else{
            [ApplicationDelegate showAlert:@"Something went wrong. Please try again."];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [ApplicationDelegate loadingDismiss];
        
    }];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnPressed_withFB:(id)sender {
    
        // If the session state is any of the two "open" states when the button is clicked
    if (FBSession.activeSession.state == FBSessionStateOpen
        || FBSession.activeSession.state == FBSessionStateOpenTokenExtended) {
        
        // Close the session and remove the access token from the cache
        // The session state handler (in the app delegate) will be called automatically
        [FBSession.activeSession closeAndClearTokenInformation];
        
        // If the session state is not any of the two "open" states when the button is clicked
    } else {
        // Open a session showing the user the login UI
        // You must ALWAYS ask for public_profile permissions when opening a session

        [FBSession openActiveSessionWithReadPermissions:@[@"public_profile",@"email",@"read_custom_friendlists"]
                                           allowLoginUI:YES
                                      completionHandler:
         ^(FBSession *session, FBSessionState state, NSError *error) {
             
             // Retrieve the app delegate
             [self sessionStateChanged:session state:state error:error];
         }];
    }
    

}
- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState) state error:(NSError *)error
{
    if (!error && state == FBSessionStateOpen)
    {
        [[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
            NSLog(@"%@",user);

            [self callRegisterAPI: user];
        }];
    }
    
    else  if (error){
        
        [ApplicationDelegate loadingDismiss];
        
        if ([FBErrorUtility shouldNotifyUserForError:error] == YES){
            [ApplicationDelegate showAlert:[FBErrorUtility userMessageForError:error]];
            
        }
        else {
            
            if ([FBErrorUtility errorCategoryForError:error] == FBErrorCategoryUserCancelled) {
                NSLog(@"User cancelled login.");
            }
            else if ([FBErrorUtility errorCategoryForError:error] == FBErrorCategoryAuthenticationReopenSession){
                
                [ApplicationDelegate showAlert:@"Your current session is no longer valid. Please log in again."];
            }
            else {
                
                [ApplicationDelegate showAlert:@"Something went wrong. Try again."];
            }
        }
        
        
    }        return ;
}


- (IBAction)btnPressed_login:(id)sender {
    
    [self callSignInAPI];

}

- (IBAction)btnPressed_forgotPassword:(id)sender {
}

- (IBAction)btnPressed_SignUp:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
