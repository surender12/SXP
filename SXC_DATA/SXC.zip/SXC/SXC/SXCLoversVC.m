//
//  SXCLoversVC.m
//  SXC
//
//  Created by Ketan on 09/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCLoversVC.h"
#import "SXCUserProfileVC.h"

@interface SXCLoversVC ()

@end

@implementation SXCLoversVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:@"Lover(s)"];
    
    UIView * backView = [[[NSBundle mainBundle] loadNibNamed:@"TableBackLoverVw" owner:self options:nil] lastObject];
    tbl_lovers.backgroundView = backView;

}

#pragma mark
#pragma mark TableView DataSource/Delegate
#pragma mark

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 0;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView * headerVw = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 80)];
    headerVw.backgroundColor = ColorBackground;
    // Button My Lovers
    UIButton *lvrBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [lvrBtn addTarget:self
               action:@selector(loversBtn)
     forControlEvents:UIControlEventTouchUpInside];
    
    NSDictionary *underlineAttribute = @{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)};
    [lvrBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:@"MY LOVER(S)"
                                                               attributes:underlineAttribute] forState:UIControlStateNormal];
    lvrBtn.titleLabel.font = FontOpenSans(12);
    lvrBtn.titleLabel.textColor = [UIColor whiteColor];
    lvrBtn.frame = CGRectMake(10.0, 8, 120, 40.0);
    [headerVw addSubview:lvrBtn];
    
    // Button FB Contacts
    UIButton *fbBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [fbBtn addTarget:self
               action:@selector(fbContactsBtn)
     forControlEvents:UIControlEventTouchUpInside];
    fbBtn.titleLabel.font = FontOpenSans(12);
    NSDictionary *underlineAttribute1 = @{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)};
    [fbBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:@"FACEBOOK CONTACTS"
                                                               attributes:underlineAttribute1] forState:UIControlStateNormal];
    
    fbBtn.frame = CGRectMake(150.0, 8, 150, 40.0);
    fbBtn.titleLabel.textColor = [UIColor whiteColor];
    [headerVw addSubview:fbBtn];
    
    return headerVw;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"cell";
    UILabel *lblTitle;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.backgroundColor = [UIColor clearColor];
    }
    
    lblTitle = (UILabel *)[cell.contentView viewWithTag:101];
    if (lblTitle) {
        lblTitle.text = @"";
    }
    
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
}

-(void)loversBtn{
//    UIView * backView = [[[NSBundle mainBundle] loadNibNamed:@"TableBackLoverVw" owner:self options:nil] lastObject];
//    tbl_lovers.backgroundView = backView;
    
    SXCUserProfileVC * objUser = VCWithIdentifier(@"SXCUserProfileVC");
    [self.navigationController pushViewController:objUser animated:YES];
    
}
-(void)fbContactsBtn{
    UIView * backView = [[[NSBundle mainBundle] loadNibNamed:@"SXCBackFBFriends" owner:self options:nil] lastObject];
    tbl_lovers.backgroundView = backView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
