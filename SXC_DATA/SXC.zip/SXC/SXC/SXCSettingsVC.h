//
//  SXCSettingsVC.h
//  SXC
//
//  Created by Ketan on 08/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXCSettingsVC : UIViewController
{
    __weak IBOutlet UISwitch *slider_permission;
    
}
- (IBAction)btnPressed_ImportFb:(id)sender;
- (IBAction)btnPressed_Save:(id)sender;

- (IBAction)btnPressed_Done:(id)sender;
@end
