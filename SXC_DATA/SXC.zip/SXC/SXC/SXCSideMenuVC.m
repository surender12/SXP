//
//  SXCSideMenuVC.m
//  SXC
//
//  Created by Ketan on 08/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCSideMenuVC.h"
#import "SXCPresentationVC.h"
#import "SXCAboutVC.h"
#import "SXCMyOpinionVC.h"
#import "SXCSettingsVC.h"
#import "SXCRegisterVC.h"

@interface SXCSideMenuVC ()

@end

@implementation SXCSideMenuVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    arrMenuItems = @[@"SETTINGS",@"MY OPINION",@"ABOUT",@"PRIVATE POLICY",@"TERM OF USE",@"LOGOUT"];
}

#pragma mark
#pragma mark TableView DataSource/Delegate
#pragma mark
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [arrMenuItems count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"cell";
    UILabel *lblTitle;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.backgroundColor = [UIColor clearColor];
    }
    
    lblTitle = (UILabel *)[cell.contentView viewWithTag:101];
    if (lblTitle) {
        lblTitle.text = arrMenuItems[indexPath.row];
    }

    
    return cell;
    
}           

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
        {
            //            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"firstViewController"]] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
            if ([UserDefaults objectForKey:@"userData"]) {
                SXCSettingsVC * objPre = VCWithIdentifier(@"SXCSettingsVC");
                [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
            }else{
                SXCRegisterVC * objPre = VCWithIdentifier(@"SXCRegisterVC");
                [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
            }
           
            
        }
            break;
        case 1:
        {
            [self.sideMenuViewController hideMenuViewController];
            if ([UserDefaults objectForKey:@"userData"]) {
                SXCSettingsVC * objPre = VCWithIdentifier(@"SXCSettingsVC");
                [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
            }else{
                SXCMyOpinionVC * objPre = VCWithIdentifier(@"SXCMyOpinionVC");
                [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
            }

        }
            break;
        case 2:
        {
            [self.sideMenuViewController hideMenuViewController];
            
            SXCAboutVC * objPre = VCWithIdentifier(@"SXCAboutVC");
        
            objPre.dictData = [[NSMutableDictionary alloc]init];
            [objPre.dictData setValue:@"About" forKey:@"type"];
            [objPre.dictData setValue:AboutUsText forKey:@"text"];
            [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
        }
            break;
        case 3:
        {
            [self.sideMenuViewController hideMenuViewController];
            
             SXCAboutVC * objPre = VCWithIdentifier(@"SXCAboutVC");
            objPre.dictData = [[NSMutableDictionary alloc]init];
            [objPre.dictData setValue:@"Private Policy" forKey:@"type"];
            [objPre.dictData setValue:PrivatePolicyText forKey:@"text"];
            [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
        }
            break;
        case 4:
        {
            [self.sideMenuViewController hideMenuViewController];
            
             SXCAboutVC * objPre = VCWithIdentifier(@"SXCAboutVC");
            objPre.dictData = [[NSMutableDictionary alloc]init];
            [objPre.dictData setValue:@"Term Of Use" forKey:@"type"];
            [objPre.dictData setValue:TermOfUseText forKey:@"text"];
            [self.sideMenuViewController.navigationController presentViewController:objPre animated:NO completion:nil];
        }
            break;
        case 5:
        {
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"SXCRegisterVC"]] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
            break;
        default:
            break;
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
