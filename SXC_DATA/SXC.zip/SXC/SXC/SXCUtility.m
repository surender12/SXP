//
//  SXCUtility.m
//  SXC
//
//  Created by Ketan on 05/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCUtility.h"


@implementation SXCUtility

static SXCUtility* singleton = nil;

+(SXCUtility*)singleton
{
    @synchronized([SXCUtility class])
    {
        if (!singleton)
            return [[self alloc] init];
        
        return singleton;
    }
    
    return nil;
}

#pragma mark
#pragma mark TxtFld Method
#pragma mark
+(UILabel *)lblTitleNavBar:(NSString *)title
{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.font = FontOpenSans(15);
    label.textAlignment = NSTextAlignmentCenter;
    label.text=title;
    label.textColor = [UIColor whiteColor]; // change this color (yellow)
    [label sizeToFit];
    return label;
    
}

#pragma mark
#pragma mark NavigationBar LeftBarButton Method
#pragma mark
+(UIBarButtonItem *)leftbar:(UIImage *)image :(UIViewController*)viewController
{
    UIButton *btnLeft = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [btnLeft setImage:image forState:UIControlStateNormal];
    [btnLeft addTarget:viewController action:@selector(leftBtn) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithCustomView:btnLeft];
    
      return left;
}
+(UIBarButtonItem *)rightbar:(UIImage *)image :(NSString*)strTitle :(UIViewController*)viewController
{
    if (strTitle.length > 0) {
        UIButton *btnRight = [[UIButton alloc] initWithFrame:CGRectMake(0,0,60,30)];
        [btnRight setTitle:strTitle forState:UIControlStateNormal];
        btnRight.titleLabel.font = FontOpenSans(12);
        [btnRight addTarget:viewController action:@selector(rightBtn) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithCustomView:btnRight];
        return right;
    }else{
    UIButton *btnRight = [[UIButton alloc] initWithFrame:CGRectMake(0,0,30,30)];
    [btnRight setImage:image forState:UIControlStateNormal];
    [btnRight addTarget:viewController action:@selector(rightBtn) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithCustomView:btnRight];
        return right;
    }
    
}
-(void)leftBtn
{
    
}
-(void)rightBtn
{
    
}



#pragma mark
#pragma mark Email Validation
#pragma mark
+(void)backGestureDisable:(UIViewController*)viewController
{
    if ([viewController.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        viewController.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
}

#pragma mark
#pragma mark Email Validation
#pragma mark
+(BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

#pragma mark
#pragma mark AFNetworking
#pragma mark
-(void)getDataForUrl:(NSString *)URLString
          parameters:(NSDictionary *)parameters
             success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
             failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager POST:URLString parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        success(operation,responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        failure(operation,error);
    }];
}


@end
    