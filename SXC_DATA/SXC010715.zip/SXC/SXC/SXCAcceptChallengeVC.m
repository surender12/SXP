//
//  SXCAcceptChallengeVC.m
//  SXC
//
//  Created by Ketan on 22/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCAcceptChallengeVC.h"

@interface SXCAcceptChallengeVC ()

@end

@implementation SXCAcceptChallengeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.title = @"";
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:
                                     _strTitle];
    self.navigationItem.leftBarButtonItem = [SXCUtility leftbar:[UIImage imageNamed:@"backArrow"] :self];
}
-(void)leftBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnPressed_Accept:(UIButton*)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
    }else{
        [sender setSelected:YES];
    }
}
@end
