//
//  SXCBackFBFriends.h
//  SXC
//
//  Created by Ketan on 11/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXCBackFBFriends : UIView

- (IBAction)btnPressed_Import:(id)sender;
@end
