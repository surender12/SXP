//
//  SXCFilterTblVW.h
//  SXC
//
//  Created by Ketan on 16/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^filterSelection)(NSMutableDictionary *dictData);

@interface SXCFilterTblVW : UIView{
    
    __weak IBOutlet UITableView *tbl_Filter;
    NSMutableArray * arrList;
    filterSelection blockFilter;
    
}
- (IBAction)btnPressed_Close:(id)sender;
-(void)callSetup;
@property (nonatomic, copy) filterSelection blockFilter;
@end
