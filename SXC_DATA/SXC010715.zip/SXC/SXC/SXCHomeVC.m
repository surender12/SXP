//
//  SXCHomeVC.m
//  SXC
//
//  Created by Ketan on 08/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCHomeVC.h"
#import "SXCSubSkillsVC.h"
#import "SXCFilterTblVW.h"

@interface SXCHomeVC ()

@end

@implementation SXCHomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.title = @"";
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:@"What I think of me"];
    
    self.navigationItem.rightBarButtonItem = [SXCUtility rightbar:nil :@"FILTER" :self];
    
    
    NSMutableDictionary *valueDictionary = [[NSMutableDictionary alloc]init];
    [valueDictionary setValue:@"0" forKey:@"PEAK CONTROL"];
    [valueDictionary setValue:@"0" forKey:@"SEXTALK"];
    [valueDictionary setValue:@"0" forKey:@"PRESENCE"];
    [valueDictionary setValue:@"0" forKey:@"LEADING"];
    [valueDictionary setValue:@"0" forKey:@"DEEP ORGASMS"];
    [valueDictionary setValue:@"0" forKey:@"PLAYFULLNESS"];
    [valueDictionary setValue:@"0" forKey:@"EMPATHY"];
    [valueDictionary setValue:@"0" forKey:@"FOLLOWING"];
    
    [SXCUtility singleton].dictRating = [valueDictionary mutableCopy];
    
    //initiate a view with the value
    _spiderView = [[BTSpiderPlotterView alloc] initWithFrame:CGRectMake(0, 0, 320, 450) valueDictionary:valueDictionary];
    _spiderView.blockFilter = ^(NSString*strTitle){
        
        NSLog(@"strTitle--%@",strTitle);
        
        
    };
    [_spiderView setMaxValue:10];
    
    UILabel *label = [[UILabel alloc] init];
    [label setFrame:CGRectMake(34, 430, 100, 20)];
    [label setText:@"MY SKILLS"];
    label.font = FontOpenSans(12);
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:[UIColor whiteColor]];
    [_spiderView addSubview:label];
    
    UIImageView * line = [[UIImageView alloc]initWithFrame:CGRectMake(0, 449, 320, 1)];
    line.image = [UIImage imageNamed:@"divider"];
    [_spiderView addSubview:line];
    
    _spiderView.plotColor = [UIColor colorWithRed:101.0f/255.0f green:47.0f/255.0f blue:139.0f/255.0f alpha:0.7f];
    _spiderView.drawboardColor = [UIColor whiteColor];

    tbl_container.tableHeaderView = _spiderView;
    
    
    arrListOfSkills = @[@{@"skill":@"PEAK CONTROL",@"description":@"Learn to control the peak orgasm."},@{@"skill":@"SEXTALK",@"description":@"Learn to say the right words."},@{@"skill":@"PRESENCE",@"description":@"How present are you with your lover?"},@{@"skill":@"LEADING",@"description":@"Guide your lover into horniness."},@{@"skill":@"DEEP ORGASMS",@"description":@"Experience deep tantric orgasms."},@{@"skill":@"PLAYFULLNESS",@"description":@"A doorway to deeper horniness."},@{@"skill":@"EMPATHY",@"description":@"Know your lovers deepest longing."},@{@"skill":@"FOLLOWING",@"description":@"Let yourself be guided deeper."}];

}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [_spiderView animateWithDuration:.1 valueDictionary:[SXCUtility singleton].dictRating];
}

-(void)rightBtn
{
    UIView * sdf = self.view.subviews.lastObject;
        if ([sdf isKindOfClass:[SXCFilterTblVW class]]) {
            [sdf removeFromSuperview];
        }else{
            SXCFilterTblVW * filterView = [[[NSBundle mainBundle] loadNibNamed:@"SXCFilterTblVW" owner:self options:nil] lastObject];
            [filterView callSetup];
            filterView.blockFilter = ^(NSDictionary*dictData){
                
                NSLog(@"dictData--%@",dictData);
                if ([[dictData valueForKey:@"title"] isEqualToString:@"Individuals rating"] || [[dictData valueForKey:@"title"] isEqualToString:@"What I think of me"] || [[dictData valueForKey:@"title"] isEqualToString:@"What others say of me"]) {
                        self.navigationItem.titleView = [SXCUtility lblTitleNavBar:[dictData valueForKey:@"title"]];
                }else{
                    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:[NSString stringWithFormat:@"Feedback: %@",[dictData valueForKey:@"title"]]];
                }
      
                
            };
            [self.view addSubview:filterView];
        }
   
}

#pragma mark
#pragma mark TableView DataSource/Delegate
#pragma mark

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return arrListOfSkills.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"cell";
    UILabel *lblTitle, *lbl_Desc;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.backgroundColor = [UIColor clearColor];
    }
    
    lblTitle = (UILabel *)[cell.contentView viewWithTag:1001];
    lbl_Desc = (UILabel *)[cell.contentView viewWithTag:1002];
    if (lblTitle) {
        lblTitle.text = [[arrListOfSkills objectAtIndex:indexPath.row] valueForKey:@"skill"];
    }
    if (lbl_Desc) {
        lbl_Desc.text = [[arrListOfSkills objectAtIndex:indexPath.row] valueForKey:@"description"];
    }
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    SXCSubSkillsVC * obj_SubSkills = VCWithIdentifier(@"SXCSubSkillsVC");
    obj_SubSkills.strTitle = [[arrListOfSkills objectAtIndex:indexPath.row] valueForKey:@"skill"];
    [self.navigationController pushViewController:obj_SubSkills animated:YES];
   
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
