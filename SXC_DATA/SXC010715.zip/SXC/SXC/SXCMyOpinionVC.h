//
//  SXCMyOpinionVC.h
//  SXC
//
//  Created by Ketan on 08/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXCMyOpinionVC : UIViewController

- (IBAction)btnPressed_Done:(id)sender;
@end
