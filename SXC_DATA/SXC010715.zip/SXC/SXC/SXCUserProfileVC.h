//
//  SXCUserProfileVC.h
//  SXC
//
//  Created by Ketan on 23/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXCUserProfileVC : UIViewController{
    
    __weak IBOutlet UITableView *tbl_Rating;
    NSArray *arrListOfSkills;
}
- (IBAction)btnPressed_Star:(id)sender;
- (IBAction)sliderValueChanged:(id)sender;

@end
