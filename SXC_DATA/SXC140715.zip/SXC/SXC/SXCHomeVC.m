//
//  SXCHomeVC.m
//  SXC
//
//  Created by Ketan on 08/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCHomeVC.h"
#import "SXCSubSkillsVC.h"
#import "SXCFilterTblVW.h"
#import "SXCGraphView.h"
#import "SXCMySkillFooter.h"
#import "SXCFeedbackFooter.h"

@interface SXCHomeVC ()

@end

@implementation SXCHomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.title = @"";
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:@"What I think of me"];
    self.navigationItem.rightBarButtonItems = [SXCUtility rightbar:[UIImage imageNamed:@"infoBtn"] :nil :self];
    
    graphView = [[[NSBundle mainBundle] loadNibNamed:@"SXCGraphView" owner:self options:nil] lastObject];
    [graphView setupGraph];
    [graphView viewSelected:NO];
    graphView.delegate = self;
   
    tbl_container.tableHeaderView = graphView;
    
    mySkillFooter = [[[NSBundle mainBundle] loadNibNamed:@"SXCMySkillFooter" owner:self options:nil] lastObject];
    mySkillFooter.delegate = self;
    tbl_container.tableFooterView = mySkillFooter;
    
    arrListOfSkills = @[@{@"skill":@"PEAK CONTROL",@"description":@"Learn to control the peak orgasm."},@{@"skill":@"SEXTALK",@"description":@"Learn to say the right words."},@{@"skill":@"PRESENCE",@"description":@"How present are you with your lover?"},@{@"skill":@"LEADING",@"description":@"Guide your lover into horniness."},@{@"skill":@"DEEP ORGASMS",@"description":@"Experience deep tantric orgasms."},@{@"skill":@"PLAYFULLNESS",@"description":@"A doorway to deeper horniness."},@{@"skill":@"EMPATHY",@"description":@"Know your lovers deepest longing."},@{@"skill":@"FOLLOWING",@"description":@"Let yourself be guided deeper."}];
    
    toolBr.hidden = YES;
    datePkr_Calendar.hidden = YES;
    datePkr_Calendar.backgroundColor = [UIColor whiteColor];
    datePkr_Calendar.maximumDate = [NSDate date];
    
//    [self callMyRatings];

}



- (void)calendarTapped{
    toolBr.hidden = NO;
    datePkr_Calendar.hidden = NO;
}

- (void)skillType:(NSString *)value{
    
    SXCSubSkillsVC * obj_SubSkills = VCWithIdentifier(@"SXCSubSkillsVC");
    obj_SubSkills.strTitle = value;
    [self.navigationController pushViewController:obj_SubSkills animated:YES];
    
}
- (void)mySkillsPressed:(NSString *)value{
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:@"What I think of me"];
    [graphView viewSelected:NO];
    tbl_container.tableFooterView = mySkillFooter;
    self.navigationItem.rightBarButtonItems = [SXCUtility rightbar:[UIImage imageNamed:@"infoBtn"] :nil :self];
}
- (void)feedbackPressed:(NSString *)value{
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:@"What others say of me"];
    [graphView viewSelected:YES];
    SXCFeedbackFooter *feedbackFooter = [[[NSBundle mainBundle] loadNibNamed:@"SXCFeedbackFooter" owner:self options:nil] lastObject];
    [feedbackFooter setupLikesFooter];
    tbl_container.tableFooterView = feedbackFooter;
    
    self.navigationItem.rightBarButtonItems = [SXCUtility rightbar:nil :@"FILTER" :self];


}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [graphView graphReload];
}


-(void)rightBtn{
    
}

-(void)rightBtnTxt
{
    UIView * sdf = self.view.subviews.lastObject;
        if ([sdf isKindOfClass:[SXCFilterTblVW class]]) {
            [sdf removeFromSuperview];
        }else{
            SXCFilterTblVW * filterView = [[[NSBundle mainBundle] loadNibNamed:@"SXCFilterTblVW" owner:self options:nil] lastObject];
            [filterView callSetup];
            filterView.blockFilter = ^(NSDictionary*dictData){
                
                NSLog(@"dictData--%@",dictData);
                if ([[dictData valueForKey:@"title"] isEqualToString:@"Individuals rating"] || [[dictData valueForKey:@"title"] isEqualToString:@"What I think of me"] || [[dictData valueForKey:@"title"] isEqualToString:@"What others say of me"]) {
                        self.navigationItem.titleView = [SXCUtility lblTitleNavBar:[dictData valueForKey:@"title"]];
                }else{
                    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:[NSString stringWithFormat:@"Feedback: %@",[dictData valueForKey:@"title"]]];
                }
      
                
            };
            [self.view addSubview:filterView];
        }
   
}

#pragma mark
#pragma mark TableView DataSource/Delegate
#pragma mark

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
//    return arrListOfSkills.count;
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"cell";
    UILabel *lblTitle, *lbl_Desc;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.backgroundColor = [UIColor clearColor];
    }
    
    lblTitle = (UILabel *)[cell.contentView viewWithTag:1001];
    lbl_Desc = (UILabel *)[cell.contentView viewWithTag:1002];
    if (lblTitle) {
        lblTitle.text = [[arrListOfSkills objectAtIndex:indexPath.row] valueForKey:@"skill"];
    }
    if (lbl_Desc) {
        lbl_Desc.text = [[arrListOfSkills objectAtIndex:indexPath.row] valueForKey:@"description"];
    }
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    SXCSubSkillsVC * obj_SubSkills = VCWithIdentifier(@"SXCSubSkillsVC");
    obj_SubSkills.strTitle = [[arrListOfSkills objectAtIndex:indexPath.row] valueForKey:@"skill"];
    [self.navigationController pushViewController:obj_SubSkills animated:YES];
   
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnPressed_DoneCal:(id)sender {
    
    toolBr.hidden = YES;
    datePkr_Calendar.hidden = YES;
    
    NSDate *date1 = datePkr_Calendar.date;
    NSDate *date2 = [NSDate date];
    
    NSTimeInterval secondsBetween = [date2 timeIntervalSinceDate:date1];
    
    int numberOfDays = secondsBetween / 86400;
    
    [mySkillFooter setUpCalendarView:[NSString stringWithFormat:@"%d",numberOfDays]];
    
    [self callSaveOrgasmDateAPI:[NSString stringWithFormat:@"%d",numberOfDays]];
    
}

-(void)callMyRatings{
    [ApplicationDelegate loadingShow];
    
//      http://www.trigmasolutions.com/SexSkill/api/GetMyOwnSkills
    
//      Keys:UserID,GetSkillType(MySkills)

    
    [[SXCUtility singleton] getDataGETForUrl:[NSString stringWithFormat:@"%@%@/%@",GetMySkillsRating,[[UserDefaults valueForKey:@"userData"] valueForKey:@"userid"],@"MySkills"] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [ApplicationDelegate loadingDismiss];
        NSLog(@"responseObject---%@",responseObject);
        
        if (responseObject && [responseObject objectAtIndex:0] && [[responseObject objectAtIndex:0] valueForKey:@"Status"] && [[[responseObject objectAtIndex:0] valueForKey:@"Status"] boolValue] == YES) {
            
            
        }else{
            
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [ApplicationDelegate loadingDismiss];
        
    }];
    
    
    
}


-(void)callSaveOrgasmDateAPI :(NSString*)days{
    [ApplicationDelegate loadingShow];
//      http://www.trigmasolutions.com/SexSkill/api/SaveUserOrgism
    
//      Keys:UserID,OrgasimDate
    
    NSMutableDictionary * dictData = [[NSMutableDictionary alloc]init];
    
    [dictData setValue:[[UserDefaults valueForKey:@"userData"] valueForKey:@"userid"] forKey:@"UserID"];
    [dictData setValue:days forKey:@"OrgasimDate"];
    
    
    [[SXCUtility singleton] getDataForUrl:SaveOrgasmDate parameters:dictData success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [ApplicationDelegate loadingDismiss];
        NSLog(@"responseObject---%@",responseObject);
        
        if (responseObject && [responseObject valueForKey:@"Status"] && [[responseObject valueForKey:@"Status"] boolValue] == YES) {
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:AppName message:@"Saved Successfully!!!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            alert.tag = 101;
            [alert show];
            
        }else{
            [ApplicationDelegate showAlert:@"Something went wrong. Try again."];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [ApplicationDelegate loadingDismiss];
        
    }];
    
    
}


@end
