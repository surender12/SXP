//
//  SXCProfileLikes.h
//  SXC
//
//  Created by Ketan on 13/07/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXCProfileLikes : UIView{
    
    __weak IBOutlet UICollectionView *collVw_Likes;
}
- (IBAction)btnPressed_AddLikes:(id)sender;
-(void)setupLikesFooter;
@end
