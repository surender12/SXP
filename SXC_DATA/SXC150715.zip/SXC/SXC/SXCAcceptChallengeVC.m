//
//  SXCAcceptChallengeVC.m
//  SXC
//
//  Created by Ketan on 22/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCAcceptChallengeVC.h"

@interface SXCAcceptChallengeVC ()

@end

@implementation SXCAcceptChallengeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.title = @"";
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:
                                     _strTitle];
    self.navigationItem.leftBarButtonItem = [SXCUtility leftbar:[UIImage imageNamed:@"backArrow"] :self];
    
    collVw_Videos.hidden = YES;
    scrollVw_Container.contentSize = CGSizeMake(272, 1300);
    
    NSMutableAttributedString *attributedString1 = [[NSMutableAttributedString alloc]
                                                   initWithString:@"INFO"];
    [attributedString1 addAttribute:NSUnderlineStyleAttributeName
                             value:@(NSUnderlineStyleSingle)
                             range:NSMakeRange(0, 4)];
    [attributedString1 addAttribute:NSFontAttributeName value:FontOpenSans(12) range:NSMakeRange(0, 4)];
    btn_Info.titleLabel.attributedText = attributedString1;
  
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]
                                                   initWithString:@"VIDEOS"];
    [attributedString addAttribute:NSUnderlineStyleAttributeName
                             value:@(NSUnderlineStyleSingle)
                             range:NSMakeRange(0, 6)];
    [attributedString addAttribute:NSFontAttributeName value:FontOpenSans(12) range:NSMakeRange(0, 6)];
    btn_Videos.titleLabel.attributedText = attributedString;
    btn_Videos.alpha = 0.5;
    
    arrVideoLinks = @[@"https://www.youtube.com/watch?v=PcE1tP7kFag",
                      @"https://www.youtube.com/watch?v=Srm5biS2R_A",
                      @"https://www.youtube.com/watch?v=bGvHj2otWwU",
                      @"https://www.youtube.com/watch?v=EAFKusQKmGU",
                      @"https://www.youtube.com/watch?v=h_9RLh3lPl8",
                      @"https://www.youtube.com/watch?v=7iENY0fswLU",
                      @"https://www.youtube.com/watch?v=imZoNGobynI",
                      @"https://www.youtube.com/watch?v=6H4B-ssPC3w",
                      @"https://www.youtube.com/watch?v=JaNEwfQzSjg",
                      @"https://www.youtube.com/watch?v=d2UxzWbcffE",
                      @"https://www.youtube.com/watch?v=y4dnvrsDgIo",
                      @"https://www.youtube.com/watch?v=AEelzkdhXwo",
                      @"https://www.youtube.com/watch?v=7ZmYh-mM9f4",
                      @"https://www.youtube.com/watch?v=glD1y5KHf8Y",
                      @"https://i.ytimg.com/vi/8sK8E8MYGh4/mqdefault.jpg",
                      @"https://www.youtube.com/watch?v=jJbcVuhtZhA",
                      @"https://www.youtube.com/watch?v=38GH9tsKW0Q",
                      @"https://www.youtube.com/watch?v=CT0OETR_pHE",
                      @"https://www.youtube.com/watch?v=AEelzkdhXwo",
                      @"https://www.youtube.com/watch?v=zWUbzm7WUhw",
                      @"https://www.youtube.com/watch?v=Eiswyf3a9H0",
                      @"https://www.youtube.com/watch?v=2RK4_-pO9hI"];
    
    
}


-(void)leftBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark Collection View Datasource/Delegates


- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section
{
    return 22;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    UIImageView * imgThumb = (UIImageView*)[cell viewWithTag:1001];
    UILabel * lblTitle = (UILabel*)[cell viewWithTag:1002];
    if (lblTitle) {
        if (indexPath.row == 0) {
            lblTitle.text = @"Intro";
        }else{
            lblTitle.text = [NSString stringWithFormat:@"Day %ld",(long)indexPath.row];
        }
        
    }
    
    if (imgThumb) {
        
        
    }
    
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary * dict  = LoadPlist(@"iframe");

    TSMiniWebBrowser *webBrowser = [[TSMiniWebBrowser alloc]initWithString:[dict valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]];
    webBrowser.delegate = self;
    webBrowser.mode = TSMiniWebBrowserModeNavigation;
        webBrowser.showActionButton = NO;
        webBrowser.showReloadButton = NO;
    webBrowser.barStyle = UIBarStyleBlack;
    
    if (webBrowser.mode == TSMiniWebBrowserModeModal) {
        webBrowser.modalDismissButtonTitle = @"CLOSE";
        [self presentViewController:webBrowser animated:YES completion:nil];
    } else if(webBrowser.mode == TSMiniWebBrowserModeNavigation) {
        [self.navigationController pushViewController:webBrowser animated:YES];
    }

    
}

-(void) tsMiniWebBrowserDidDismiss {
    NSLog(@"TSMiniWebBrowser was dismissed");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnPressed_InfoVideoTab:(UIButton*)sender {
    
    if (sender.tag == 1022) {
        collVw_Videos.hidden = YES;
        lbl_Info.hidden = NO;
        btn_Videos.alpha = 0.5;
        btn_Info.alpha = 1.0;
        
        scrollVw_Container.contentSize = CGSizeMake(272, 1300);
    }else{
        collVw_Videos.hidden = NO;
        lbl_Info.hidden = YES;
        btn_Videos.alpha = 1.0;
        btn_Info.alpha = 0.5;
        [collVw_Videos reloadData];
        float height = collVw_Videos.contentSize.height;
        [collVw_Videos setFrame:CGRectMake(collVw_Videos.frame.origin.x, collVw_Videos.frame.origin.y, collVw_Videos.frame.size.width, height)];
        
        scrollVw_Container.contentSize = CGSizeMake(272, 350+height);
    }
}

- (IBAction)btnPressed_Accept:(UIButton*)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
    }else{
        [sender setSelected:YES];
    }
}
@end
