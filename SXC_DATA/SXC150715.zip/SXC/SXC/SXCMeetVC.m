//
//  SXCMeetVC.m
//  SXC
//
//  Created by Ketan on 09/06/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCMeetVC.h"

@interface SXCMeetVC ()

@end

@implementation SXCMeetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.titleView = [SXCUtility lblTitleNavBar:@"Meet"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnPressed_LetMeKnow:(id)sender {
    
    UIAlertView* dialog = [[UIAlertView alloc] init];
    [dialog setDelegate:self];
    [dialog setTitle:@"SXC"];
    [dialog setMessage:@"Enter Your Email ID."];
    [dialog addButtonWithTitle:@"Cancel"];
    [dialog addButtonWithTitle:@"Send"];
    dialog.tag = 5;
    dialog.alertViewStyle = UIAlertViewStylePlainTextInput;
    [dialog show];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    [self.view endEditing:YES];
    if (alertView.tag == 5) {
        UITextField *emailField = [alertView textFieldAtIndex:0];
        NSLog(@"emailField--%@",emailField.text);
        if ([SXCUtility validateEmailWithString:emailField.text] == NO)
        {
            [ApplicationDelegate showAlert:@"Invalid Email ID"];
        }
        else
        {
            
        }
    }
}

@end
