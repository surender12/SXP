//
//  SXCProfileLikes.m
//  SXC
//
//  Created by Ketan on 13/07/15.
//  Copyright (c) 2015 Trigma. All rights reserved.
//

#import "SXCProfileLikes.h"

@implementation SXCProfileLikes

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void)setupLikesFooter{
    
    [collVw_Likes registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    [collVw_Likes reloadData];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 8;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor clearColor];
    
    UIImageView * imgback = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 115, 20)];
    imgback.backgroundColor = [UIColor lightGrayColor];
    imgback.alpha = 0.5;
    [cell addSubview:imgback];
    
    UIImageView * imgStar = [[UIImageView alloc]initWithFrame:CGRectMake(5, 2, 14, 14)];
    imgStar.image = [UIImage imageNamed:@"star_green"];
    [cell addSubview:imgStar];
    
    UILabel *lblLike = [[UILabel alloc]initWithFrame:CGRectMake(25, 0, 90, 20)];
    lblLike.text = @"PEAK CONTROL";
    lblLike.textColor = [UIColor whiteColor];
    lblLike.minimumScaleFactor = 0.5;
    lblLike.font = FontSemibold(10);
    [cell addSubview:lblLike];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

#pragma mark Collection view layout things
// Layout: Set cell size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
//    NSLog(@"SETTING SIZE FOR ITEM AT INDEX %ld", (long)indexPath.row);
    CGSize mElementSize = CGSizeMake(115, 25);
    return mElementSize;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}


- (IBAction)btnPressed_AddLikes:(id)sender {
}
@end
