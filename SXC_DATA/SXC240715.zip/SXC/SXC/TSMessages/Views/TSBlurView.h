

#import <UIKit/UIKit.h>

@interface TSBlurView : UIView

@property (nonatomic, strong) UIColor *blurTintColor;

@end
